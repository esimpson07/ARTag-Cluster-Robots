#!/usr/bin/python3.8
from telnetlib import Telnet
import time
import roslib; roslib.load_manifest('wsjs')
import rospy
import tf.transformations
from geometry_msgs.msg import Twist
x = 0
y = 0
z = 0
tn = None
cats = b'510510'
currentTime = 0
pastTime = 0
delay = 250


def callback(msg):
    global cats
    rospy.loginfo("Received a /cmd_vel message!")
    rospy.loginfo("Linear Components: [%f, %f, %f]"%(msg.linear.x, msg.linear.y, msg.linear.z))
    rospy.loginfo("Angular Components: [%f, %f, %f]"%(msg.angular.x, msg.angular.y, msg.angular.z))
    x = msg.linear.x
    y = msg.angular.z / 2.5
    z = msg.linear.z
    ld = x - y
    rd = x + y
    m = max(abs(ld),abs(rd))
    if(m > 1):
    	ld = ld / m
    	rd = rd / m
    cats = bytes(str(str(int(255 * (ld + 1)) + 255) + str(int(255 * (rd + 1)) + 255)), 'utf-8')
    tn.write(cats)
    rospy.loginfo("Telnet interacting!:[%s]"%cats)
    

def listener():
    global currentTime
    global pastTime
    global delay
    global cats
    global tn
    currentTime = time.time() * 1000
    if(currentTime >= pastTime + delay):
    	pastTime = currentTime
    rospy.init_node("cmd_vel_listener")
    ipaddress = rospy.get_param("~ipaddress")
    port = rospy.get_param("~port")
    rospy.Subscriber("/input_joy/cmd_vel", Twist, callback)
    tn = Telnet(ipaddress, port)
    

    
    rospy.spin()

if __name__ == '__main__':
    listener()
